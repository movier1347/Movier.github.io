import React from "react";

function Error(props) {
  return (
        <h3>Oops! This Page cannot be found  :( ....</h3>
    );
}

export default Error;